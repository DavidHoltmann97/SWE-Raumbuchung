package com.example.raumbuchungsapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {


    TextView[][] tablearray = new TextView[12][5];
    Calendar kalender = Calendar.getInstance(Locale.GERMANY);
    private int ID;
    private Button start;
    private Button input;
    private Button anmelden;
    private Button registrieren;
    private Button zurückzurStartseite;
    private Button suchen;
    private EditText editText_benutzername;
    private EditText editText_passwort;
    private EditText editText_rename;
    private EditText editText_repasswort;
    private EditText editText_repasswortbe;
    private EditText editText_matrikelnummer;
    private EditText editText_studiengang;
    private EditText editText_input;
    private TextView textView_raumnummer;
    private EditText editText_zeitvon;
    private Button suchicon;
    private TextView textView_raum;
    private TextView textView_zeitvon;
    private TextView textView_zeitbis;
    private TextView textView_datum;
    private Button buchen;
    private TableLayout tablelayout;
    private TextView Montag;
    private TextView Dienstag;
    private TextView Mittwoch;
    private TextView Donnerstag;
    private TextView Freitag;
    private TextView Mo8, Mo9, Mo10, Mo11, Mo12, Mo13, Mo14, Mo15, Mo16, Mo17, Mo18, Mo19, Mo20;
    private TextView Di8, Di9, Di10, Di11, Di12, Di13, Di14, Di15, Di16, Di17, Di18, Di19, Di20;
    private TextView Mi8, Mi9, Mi10, Mi11, Mi12, Mi13, Mi14, Mi15, Mi16, Mi17, Mi18, Mi19, Mi20;
    private TextView Do8, Do9, Do10, Do11, Do12, Do13, Do14, Do15, Do16, Do17, Do18, Do19, Do20;
    private TextView Fr8, Fr9, Fr10, Fr11, Fr12, Fr13, Fr14, Fr15, Fr16, Fr17, Fr18, Fr19, Fr20;

    public TextView getTextView_datum() {
        return textView_datum;
    }

    public void setTextView_datum(TextView textView_datum) {
        this.textView_datum = textView_datum;
    }

    public List<User> getBenutzerliste() {
        return Benutzerliste;
    }

    public void setBenutzerliste(List<User> benutzerliste) {
        Benutzerliste = benutzerliste;
    }

    List<User> Benutzerliste = new ArrayList<User>();
    List<Raum> räume = new ArrayList<Raum>();
    List<Buchung> buchungen = new ArrayList<Buchung>();
    Verwaltung verwaltung = new Verwaltung(räume);

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tablearray[8][0] = Mo8; tablearray[9][0] = Mo9; tablearray[10][0] = Mo10; tablearray[11][0] = Mo11; tablearray[12][0] = Mo12; tablearray[13][0] = Mo13; tablearray[14][0] = Mo14; tablearray[15][0] = Mo15; tablearray[16][0] = Mo16; tablearray[17][0] = Mo17; tablearray[18][0] = Mo18; tablearray[19][0] = Mo19; tablearray[20][0] = Mo20;
        tablearray[8][1] = Di8; tablearray[9][1] = Di9; tablearray[10][1] = Di10; tablearray[11][1] = Di11; tablearray[12][1] = Di12; tablearray[13][1] = Di13; tablearray[14][1] = Di14; tablearray[15][1] = Di15; tablearray[16][1] = Di16; tablearray[17][1] = Di17; tablearray[18][1] = Di18; tablearray[19][1] = Di19; tablearray[20][1] = Di20;
        tablearray[8][2] = Mi8; tablearray[9][2] = Mi9; tablearray[10][2] = Mi10; tablearray[11][2] = Mi11; tablearray[12][2] = Mi12; tablearray[13][2] = Mi13; tablearray[14][2] = Mi14; tablearray[15][2] = Mi15; tablearray[16][2] = Mi16; tablearray[17][2] = Mi17; tablearray[18][2] = Mi18; tablearray[19][2] = Mi19; tablearray[20][2] = Mi20;
        tablearray[8][3] = Do8; tablearray[9][3] = Do9; tablearray[10][3] = Do10; tablearray[11][3] = Do11; tablearray[12][3] = Do12; tablearray[13][3] = Do13; tablearray[14][3] = Do14; tablearray[15][3] = Do15; tablearray[16][3] = Do16; tablearray[17][3] = Do17; tablearray[18][3] = Do18; tablearray[19][3] = Do19; tablearray[20][3] = Do20;
        tablearray[8][4] = Fr8; tablearray[9][4] = Fr9; tablearray[10][4] = Fr10; tablearray[11][4] = Fr11; tablearray[12][4] = Fr12; tablearray[13][4] = Fr13; tablearray[14][4] = Fr14; tablearray[15][4] = Fr15; tablearray[16][4] = Fr16; tablearray[17][4] = Fr17; tablearray[18][4] = Fr18; tablearray[19][4] = Fr19; tablearray[20][4] = Fr20;

        final SimpleDateFormat stunden = new SimpleDateFormat("H");
        tablelayout = findViewById(R.id.tablelayout);
        for (int z = 8;z <21; z++)
        {
            for (int s = 0; s <5; s++)
            {
                TextView t = tablearray[z][s];

                SimpleDateFormat tag = new SimpleDateFormat("u");

                for (Buchung b: buchungen)
                {
                    if (Integer.parseInt(tag.format(b.datum)) == 1 && Integer.parseInt(stunden.format(b.zeitvon)) >= z && Integer.parseInt(stunden.format(b.zeitbis)) <= z )
                    {
                        tablearray[z][0].setBackgroundColor(Color.BLACK);
                    }

                    if (Integer.parseInt(tag.format(b.datum)) == 2 && Integer.parseInt(stunden.format(b.zeitvon)) >= z && Integer.parseInt(stunden.format(b.zeitbis)) <= z )
                    {
                        tablearray[z][1].setBackgroundColor(Color.BLACK);
                    }

                    if (Integer.parseInt(tag.format(b.datum)) == 3 && Integer.parseInt(stunden.format(b.zeitvon)) >= z && Integer.parseInt(stunden.format(b.zeitbis)) <= z )
                    {
                        tablearray[z][2].setBackgroundColor(Color.BLACK);
                    }

                    if (Integer.parseInt(tag.format(b.datum)) == 4 && Integer.parseInt(stunden.format(b.zeitvon)) >= z && Integer.parseInt(stunden.format(b.zeitbis)) <= z )
                    {
                        tablearray[z][3].setBackgroundColor(Color.BLACK);
                    }

                    if (Integer.parseInt(tag.format(b.datum)) == 5 && Integer.parseInt(stunden.format(b.zeitvon)) >= z && Integer.parseInt(stunden.format(b.zeitbis)) <= z )
                    {
                        tablearray[z][4].setBackgroundColor(Color.BLACK);
                    }
                }

            }
        }

        final SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY);

        if (kalender.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY)
        {
            for (int z = 8; z < 21; z++)
            {
                for (int s = 0; s < 5; s++)
                {
                    tablearray[z][s].setBackgroundColor(Color.WHITE);
                }
            }

            String montag = dateFormat.format(kalender.getTime());
            kalender.set(Calendar.YEAR, Calendar.MONTH, Calendar.DATE + 1);
            String dienstag = dateFormat.format(kalender.getTime());
            kalender.set(Calendar.YEAR, Calendar.MONTH, Calendar.DATE + 2);
            String mittwoch = dateFormat.format(kalender.getTime());
            kalender.set(Calendar.YEAR, Calendar.MONTH, Calendar.DATE + 3);
            String donnerstag = dateFormat.format(kalender.getTime());
            kalender.set(Calendar.YEAR, Calendar.MONTH, Calendar.DATE + 4);
            String freitag = dateFormat.format(kalender.getTime());
            Montag = findViewById(R.id.Montag);
            Montag.setText("Montag, der " + montag);
            Dienstag = findViewById(R.id.Dienstag);
            Dienstag.setText("Dienstag, der " + dienstag);
            Mittwoch = findViewById(R.id.Mittwoch);
            Mittwoch.setText("Mittwoch, der " + mittwoch);
            Donnerstag = findViewById(R.id.Donnerstag);
            Donnerstag.setText("Donnerstag, der " + donnerstag);
            Freitag = findViewById(R.id.Freitag);
            Freitag.setText("Freitag, der " + freitag);
        }

        start = findViewById(R.id.start);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                fragment_start();
            }
        });

        input = findViewById(R.id.button_login);
        input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                fragment_login();
            }
        });

        anmelden = findViewById(R.id.button_anmelden);
        anmelden.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                for (User u: Benutzerliste )
                {
                    if(u.getBenutzername() == editText_benutzername.toString() && u.getPasswort() == editText_passwort.toString())
                    {
                        fragment_anmelden();
                    }
                    else
                    {
                        System.out.println("Der Benutzer konnte nicht gefunden werden. Bitte überprüfen Sie Ihre eingegebenen Daten.");
                    }
                }
            }
        });

        registrieren = findViewById(R.id.button_registrieren);
        registrieren.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (editText_rename != null && editText_repasswort != null && editText_repasswort == editText_repasswortbe && editText_matrikelnummer != null && editText_studiengang != null)
                {
                    Benutzerliste.add(new User(editText_rename.toString(), editText_repasswort.toString(), ID, Integer.parseInt(editText_matrikelnummer.toString()), editText_studiengang.toString()));
                    fragment_registrieren();
                }
                else
                {
                    System.out.println("Fehler! Bitte überprüfen Sie Ihre Eingaben.");
                }

            }
        });

        zurückzurStartseite = findViewById(R.id.zurückzumStart);
        zurückzurStartseite.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                fragment_zurückzumStart();
            }
        });

        suchen = findViewById(R.id.button_suchen);
        suchen.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                for (Raum r: räume)
                {
                    if(editText_input.toString() == r.getRaumname())
                    {
                        fragment_suchen();
                    }
                    else
                    {
                        System.out.println("Fehler! Den angegebenen Raum gibt es nicht.");
                    }
                }

            }
        });

        suchicon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                for (Buchung b: buchungen)
                {
                    if(b.raum.getRaumname() == textView_raum.toString() && b.datum.toString() == textView_datum.toString() && Integer.parseInt(textView_zeitvon.toString()) < Integer.parseInt(b.zeitbis.toString()) && Integer.parseInt(textView_zeitbis.toString()) > Integer.parseInt(b.zeitvon.toString()))
                    {
                        System.out.println("Fehler! Dieser Raum ist zur gewünschten Zeit leider schon ausgebucht.");
                    }
                    else
                    {
                        fragment_kalender();
                    }

                }

            }
        });

        buchen.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                for (User user: Benutzerliste)
                {
                    if (user.getBenutzername() == editText_rename.toString() && user.getMatrikelnummer() == Integer.parseInt(editText_matrikelnummer.toString()))
                    {
                        for (Raum raum: räume)
                        {
                            if (raum.getRaumname() == textView_raum.toString())
                            {
                                SimpleDateFormat annahme = new SimpleDateFormat("dd.MM.yyyy");
                                Date datum = null;
                                Date zeitvon = null;
                                Date zeitbis = null;
                                try
                                {
                                    datum = dateFormat.parse(textView_datum.toString());
                                    zeitvon = stunden.parse(textView_zeitvon.toString());
                                    zeitbis = stunden.parse(textView_zeitbis.toString());
                                }
                                catch (ParseException pe)
                                {
                                    System.out.println("Fehler!");
                                }

                                buchungen.add(new Buchung(user, raum, datum, zeitvon, zeitbis));
                                fragment_buchen();
                            }
                        }
                    }
                }

            }
        });

        editText_benutzername = findViewById(R.id.edittext_benutzername);
        editText_passwort = findViewById(R.id.edittext_passwort);
        editText_rename = findViewById(R.id.editText_rename);
        editText_repasswort = findViewById(R.id.editText_repasswort);
        editText_repasswortbe = findViewById(R.id.editText_repasswortbe);
        editText_matrikelnummer = findViewById(R.id.editText_matrikelnummer);
        editText_studiengang = findViewById(R.id.editText_studiengang);
        editText_input = findViewById(R.id.editText_input);
        textView_raumnummer = findViewById(R.id.viewraumnummer);
        textView_raumnummer.setText(editText_input.getText());
        editText_zeitvon = findViewById(R.id.zeitvon);
        textView_raum = findViewById(R.id.textView_raumnummer);
        textView_raum.setText(editText_input.getText());
        textView_datum = findViewById(R.id.TextView_datum);
        textView_zeitbis = findViewById(R.id.TextView_zeitbis);
        textView_zeitvon = findViewById(R.id.TextView_zeitvon);
        Mo8 = findViewById(R.id.Mo8);Mo9 = findViewById(R.id.Mo9);Mo10 = findViewById(R.id.Mo10);Mo11 = findViewById(R.id.Mo11);Mo12 = findViewById(R.id.Mo12);Mo13 = findViewById(R.id.Mo13);Mo14 = findViewById(R.id.Mo14);Mo15 = findViewById(R.id.Mo15);Mo16 = findViewById(R.id.Mo16);Mo17 = findViewById(R.id.Mo17);Mo18 = findViewById(R.id.Mo18);Mo19 = findViewById(R.id.Mo19);Mo20 = findViewById(R.id.Mo20);
        Di8 = findViewById(R.id.Di8);Di9 = findViewById(R.id.Di9);Di10 = findViewById(R.id.Di10);Di11 = findViewById(R.id.Di11);Di12 = findViewById(R.id.Di12);Di13 = findViewById(R.id.Di13);Di14 = findViewById(R.id.Di14);Di15 = findViewById(R.id.Di15);Di16 = findViewById(R.id.Di16);Di17 = findViewById(R.id.Di17);Di18 = findViewById(R.id.Di18);Di19 = findViewById(R.id.Di19);Di20 = findViewById(R.id.Di20);
        Mi8 = findViewById(R.id.Mi8);Mi9 = findViewById(R.id.Mi9);Mi10 = findViewById(R.id.Mi10);Mi11 = findViewById(R.id.Mi11);Mi12 = findViewById(R.id.Mi12);Mi13 = findViewById(R.id.Mi13);Mi14 = findViewById(R.id.Mi14);Mi15 = findViewById(R.id.Mi15);Mi16 = findViewById(R.id.Mi16);Mi17 = findViewById(R.id.Mi17);Mi18 = findViewById(R.id.Mi18);Mi19 = findViewById(R.id.Mi19); Mi20 = findViewById(R.id.Mi20);
        Do8 = findViewById(R.id.Do8);Do9 = findViewById(R.id.Do9);Do10 = findViewById(R.id.Do10);Do11 = findViewById(R.id.Do11);Do12 = findViewById(R.id.Do12);Do13 = findViewById(R.id.Do13);Do14 = findViewById(R.id.Do14);Do15 = findViewById(R.id.Do15);Do16 = findViewById(R.id.Do16);Do17 = findViewById(R.id.Do17);Do18 = findViewById(R.id.Do18);Do19 = findViewById(R.id.Do19); Do20 = findViewById(R.id.Do20);
        Fr8 = findViewById(R.id.Fr8);Fr9 = findViewById(R.id.Fr9);Fr10 = findViewById(R.id.Fr10);Fr11 = findViewById(R.id.Fr11);Fr12 = findViewById(R.id.Fr12);Fr13 = findViewById(R.id.Fr13);Fr14 = findViewById(R.id.Fr14);Fr15 = findViewById(R.id.Fr15);Fr16 = findViewById(R.id.Fr16);Fr17 = findViewById(R.id.Fr17);Fr18 = findViewById(R.id.Fr18);Fr19 = findViewById(R.id.Fr19); Fr20 = findViewById(R.id.Fr20);
    }


    public void fragment_start()
    {
        Intent intent_start = new Intent(this, fragment_input.class);
        startActivity(intent_start);
    }


    public void fragment_login()
    {
        Intent intent_login = new Intent(this, fragment_login.class);
        startActivity(intent_login);
    }

    public void fragment_anmelden()
    {
        Intent intent_anmelden = new Intent(this, fragment_raumauswahl.class);
        startActivity(intent_anmelden);
    }
    public void fragment_registrieren()
    {
        Intent intent_registrieren = new Intent(this, fragment_registrieren.class);
        startActivity(intent_registrieren);
    }
    public void fragment_zurückzumStart()
    {
        Intent intent_zurückzumStart = new Intent(this, fragment_input.class);
        startActivity(intent_zurückzumStart);
    }
    public void fragment_suchen()
    {
        Intent intent_suchen = new Intent(this, fragment_kalender.class);
        startActivity(intent_suchen);
    }
    public void fragment_kalender()
    {
        Intent intent_calender = new Intent(this, fragment_frei_alternativen.class);
        startActivity(intent_calender);
    }
    public void fragment_buchen()
    {
        Intent intent_buchen = new Intent(this, fragment_bestaetigung.class);
        startActivity(intent_buchen);
    }
}
