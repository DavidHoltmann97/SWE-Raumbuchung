// Kommentarzeile

/*

Multiple Kommentarzeilen hier

 */

package com.example.raumbuchungsapp;

import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class  Admin extends User
{
    public Admin(String Benutzername, String Passwort, int ID, int Matrikelnummer, String Studiengang)
    {
        super(Benutzername, Passwort, ID, Matrikelnummer, Studiengang);
    }


    public MainActivity b = new MainActivity();


    public void Benutzeranlegen(User user)
    {
        if (!b.getBenutzerliste().contains(user))
        {
            b.getBenutzerliste().add(user);
        }
        System.out.println("Benutzer wurde bereits angelegt.");
    }
    public void Benutzerloeschen(User user)
    {
        if (!b.getBenutzerliste().contains(user))
        {
            System.out.println("Benutzer wurde nicht gefunden und kann nicht gelöscht werden.");
        }
        b.getBenutzerliste().remove(user);
    }

}

